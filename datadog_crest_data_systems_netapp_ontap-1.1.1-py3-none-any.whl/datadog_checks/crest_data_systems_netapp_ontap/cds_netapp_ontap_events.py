import time
from datetime import datetime

from .cds_netapp_ontap_utils import field_alias_generator, field_parser, ingest_logs, search_checkpoint_log
from .NetApp.NaElement import NaElement


class EventsIngester:
    def __init__(self, instance_check) -> None:
        """Initialize the eventsingester."""
        self.instance_check = instance_check
        self.client = instance_check.client
        self.log = self.instance_check.log

    def events_field_parser(self, event):
        # generate a key-valye pair of event
        fields = [
            "ems-severity",
            "event",
            "message-name",
            "node",
            "num-suppressed-since-last",
            "seq-num",
            "severity",
            "source",
            "time",
            "version",
        ]
        event = field_parser(event, fields)

        alias = {
            "ems-severity": ["ems-severity"],
            "event": ["event"],
            "message-name": ["message-name"],
            "node": ["node"],
            "num-suppressed-since-last": ["num-suppressed-since-last"],
            "sequence-num": ["seq-num"],
            "severity": ["severity"],
            "source": ["source"],
            "timestamp": ["time"],
            "version": ["version"],
        }

        return field_alias_generator(event, alias)

    def events_tag(self, event):
        # generate events tag
        fields = [
            "ems-severity",
            "event",
            "message-name",
            "node",
            "num-suppressed-since-last",
            "sequence-num",
            "severity",
            "source",
            "timestamp",
            "version",
        ]
        tags = []
        event = field_parser(event, fields)
        for field in event:
            tags.append(f"{field}:{event.get(field)}")
        return tags

    def get_checkpoint(self):
        """Get the checkpoint from the datadog."""
        data = search_checkpoint_log(
            self.instance_check,
        )
        return data.get("time", None)

    def generate_query_element(self, time=None, record=100000000):
        """Generate a query element for API calls."""
        if self.client.isClustered():
            ems_msg_iter_element = NaElement("ems-message-get-iter")
        else:
            ems_msg_iter_element = NaElement("ems-message-get")
        max_record_element = NaElement("max-records", record)
        query_element = NaElement("query")
        ems_msg_info_element = NaElement("ems-message-info")

        if time:
            time_element = NaElement("time", time)
            ems_msg_info_element.child_add(time_element)

        query_element.child_add(ems_msg_info_element)
        ems_msg_iter_element.child_add(max_record_element)
        ems_msg_iter_element.child_add(query_element)

        return ems_msg_iter_element

    def ingestor(self):
        # collect events data
        try:
            responses = {}
            time_list = []
            events = {}
            events_list = []
            prev_time = self.get_checkpoint()
            if prev_time:
                ems_msg_iter_element = self.generate_query_element(">{}".format(int(prev_time)))
            else:
                ems_msg_iter_element = self.generate_query_element(">{}".format(int(time.time()) - 64800))

            responses = self.client.queryApi(ems_msg_iter_element)

            if not responses:
                self.log.info("NETAPP ONTAP INFO: Nothing to ingest in events details.")
                return

            if responses.get("attributes-list"):
                events = responses["attributes-list"]

            if isinstance(events, dict):
                events = events.get("ems-message-info", {})

            for event in events:
                event = self.events_field_parser(event)
                time_list.append(event.get("timestamp"))
                event["timestamp"] = datetime.utcfromtimestamp(int(event["timestamp"])).strftime("%Y-%m-%dT%H:%M:%SZ")
                events_list.append(event)

            ingest_logs(
                self.instance_check,
                "event_details",
                events_list,
                fn_to_evaluate_event=lambda event: (
                    event,
                    [
                        f"host:{self.instance_check.host}",
                    ],
                ),
            )

        except Exception as err:
            self.log.error("NETAPP ONTAP ERROR: Error occurred while ingesting 'Events' Data.")
            self.log.exception(err)

        try:
            if time_list:
                ingest_logs(
                    self.instance_check,
                    "events_checkpoint",
                    [{"time": max(time_list)}],
                    fn_to_evaluate_event=lambda event: (
                        event,
                        [
                            f"host:{self.instance_check.host}",
                        ],
                    ),
                )
        except Exception as err:
            self.log.error("NETAPP ONTAP ERROR: Error occurred while ingesting 'Events Checkpoint' Data.")
            self.log.exception(err)
